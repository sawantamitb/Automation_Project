package com.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.start.start;
import com.utilities.reference;

public class home extends pagefactory {

	public ExtentTest logger = start.logger;
	public reference ref = null;

	@FindBy(id = "interaction_table_header")
	public WebElement infoText;

	@FindBy(linkText = "Click here to continue")
	public WebElement continue_link;

	@FindBy(css = "#emailAddress")
	public WebElement email_text;

	@FindBy(css = ".LoginBtn")
	public WebElement logon;

	@FindBy(css = "#input_2")
	public WebElement password_element;

	public home(WebDriver driver) {
		super(driver);
		AjaxElementLocatorFactory agaxFactory = new AjaxElementLocatorFactory(
				driver, 100);
		PageFactory.initElements(agaxFactory, this);
		ref = new reference(driver);

	}

	public home click_continue() throws InterruptedException {

		try {

			String info = infoText.getText();
			if (info.contains("The account information you've provided cannot be located in our records.")) {
				logger.log(LogStatus.INFO,
						"The account information you've provided cannot be located in our records.");
				logger.log(LogStatus.INFO, "Clicking here");

				continue_link.click();
				logger.log(LogStatus.PASS, "Clicked on continue link");

			}
		} catch (Exception e) {

		}

		Thread.sleep(500);
		return this;
	}

	public home enter_username_and_click_logon(String username) {

		email_text.sendKeys(username);
		logger.log(LogStatus.PASS, "Entered username " + username);
		logon.click();
		logger.log(LogStatus.PASS, "Clicked button logon");
		String path = ref.getScreenshot();
		logger.log(LogStatus.PASS,
				"adding screen capure " + logger.addScreenCapture(path));
		return this;
	}

	public home enter_password_and_click_logon(String password) {

		password_element.sendKeys(password);
		logger.log(LogStatus.PASS, "Entered password ");
		logon.click();
		logger.log(LogStatus.PASS, "Clicked button logon");
		return this;
	}

}
