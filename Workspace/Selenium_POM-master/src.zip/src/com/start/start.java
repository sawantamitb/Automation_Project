package com.start;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.pages.pagefactory;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.utilities.ExcelManager;

//import org.openqa.selenium.support.ui.Select;

public class start {

	public static String browser = "", IEDriverPath = "",
			ChromeDriverPath = "", AppUrl = "", FirefoxDriverPath = "";
	public WebDriver driver = null;
	public static String url;
	public static ExcelManager xldriver = new ExcelManager();
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static Properties props = null;
	public ThreadLocal<RemoteWebDriver> remotedriver = null;

	@SuppressWarnings({ "finally", "deprecation" })
	public pagefactory launch_browser() {
		props = getPropertiesValues("./data/config.properties");
		browser = props.getProperty("Browser");
		try {
			if (browser.equalsIgnoreCase("IE")) {
				IEDriverPath = props.getProperty("IEDriver");

				DesiredCapabilities caps = DesiredCapabilities
						.internetExplorer();
				caps.setCapability(
						InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						false);
				caps.setCapability("ignoreZoomSetting", true);
				caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				caps.setCapability(CapabilityType.SUPPORTS_ALERTS, true);
				caps.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						true);
				caps.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
				caps.setCapability(CapabilityType.SUPPORTS_APPLICATION_CACHE,
						false);
				System.setProperty("webdriver.ie.driver", IEDriverPath);
				driver = new InternetExplorerDriver(caps);
				// driver.findElement(By.tagName(ConfigFilePath.HTML.getConstantValue()))
				// .sendKeys(Keys.chord(Keys.CONTROL, "0"));
				driver.manage().window().maximize();
				driver.manage().timeouts()
						.pageLoadTimeout(120, TimeUnit.SECONDS);
				// driver.manage().deleteAllCookies();
				System.out.println("IE Browser launched");
				driver.get(props.getProperty("URL"));
			} else if (browser.equalsIgnoreCase("FF")) {
				FirefoxDriverPath = System.getProperty("user.dir")
						+ props.getProperty("GeckoDriverWindows");
				System.setProperty("webdriver.gecko.driver", FirefoxDriverPath);
				DesiredCapabilities capabilities = DesiredCapabilities
						.firefox();
				capabilities.setCapability("marionette", true);
				capabilities.setCapability("platform", "WINDOWS");
				// driver = new FirefoxDriver(capabilities);
				driver = new RemoteWebDriver(new URL(
						"http://localhost:4444/wd/hub"), capabilities);
				// driver.findElement(
				// By.tagName(ConfigFilePath.HTML.getConstantValue()))
				// .sendKeys(Keys.chord(Keys.CONTROL, "0"));
				driver.manage().window().maximize();
				// driver.manage().deleteAllCookies();
				driver.get(props.getProperty("URL"));
				System.out.println("FireFox Driver Is Launched.");
			} else if (browser.equalsIgnoreCase("Chrome")) {
				System.out.println("In Chrome Browser");
				ChromeDriverPath = System.getProperty("user.dir")
						+ props.getProperty("ChromeDriverWindows");
				DesiredCapabilities caps = DesiredCapabilities.chrome();
				ChromeOptions options = new ChromeOptions();
				// options.addArguments("--start-maximized");
				// options.addArguments("chrome.switches","--disable-extensions");
				// options.addArguments("--test-type");
				caps.setCapability("chrome.binary", ChromeDriverPath);
				caps.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
						UnexpectedAlertBehaviour.ACCEPT);
				caps.setCapability(ChromeOptions.CAPABILITY, options);
				// Added 12/12
				caps.setCapability("seleniumProtocol", "WebDriver");
				System.setProperty("webdriver.chrome.driver", ChromeDriverPath);
				String Type = props.getProperty("Type");

				if (Type.equals("Local")) {
					driver = new ChromeDriver(caps);
					driver.manage().window().maximize();
					// driver.manage().deleteAllCookies();
					driver.get(props.getProperty("URL"));
					// driver.navigate().refresh();
					// driver.manage().getCookies();

				} else {
					String IPAddress = props.getProperty("IPAddress");
					remotedriver.set(new RemoteWebDriver(new URL(
							"http://localhost:4444/wd/hub"), caps));
					remotedriver.set(new RemoteWebDriver(new URL(IPAddress),
							caps));
					driver = remotedriver.get();
					driver.manage().window().maximize();
					// driver.manage().deleteAllCookies();
					driver.get(props.getProperty("URL"));

				}
			}
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			return new pagefactory(driver);
		}

	}

	public WebDriver getDriver() {
		return driver;
	}

	public synchronized static void set_Logger(String tcname) {
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		long time = cal.getTimeInMillis();
		extent = new ExtentReports(System.getProperty("user.dir")
				+ "/test-output/epp_ExtentReport_" + time + ".html", true);
		extent.addSystemInfo("Host Name", "TestMachine")
				.addSystemInfo("Environment", "Automation Testing")
				.addSystemInfo("User Name", "eppTester");

		extent.loadConfig(new File(System.getProperty("user.dir")
				+ "\\extent-config.xml"));
		logger = extent.startTest(tcname);
		logger.log(LogStatus.INFO, "Logger Started");
	}

	public Properties getPropertiesValues(String filePath) {
		Properties getPropertiesValues = null;
		FileInputStream file = null;
		try {
			getPropertiesValues = new Properties();
			getPropertiesValues.load(new FileInputStream(filePath));
		} catch (Exception e) {

		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					System.out.println("Exception thrown  :" + e.getMessage());
				}
			}
		}
		return getPropertiesValues;
	}
}
