package com.tests;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.relevantcodes.extentreports.LogStatus;
import com.start.start;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class testcases {

	public start st = null;
	public static String SheetPath = "./data/TestData_epp.xlsx";

	@Test
	public void login_Test_Case_01() {
		try {
			String SheetName = Thread.currentThread().getStackTrace()[1]
					.getMethodName();

			start.xldriver.SetExcelSheet(SheetPath, "login_Test_Case_01");
			start.set_Logger(SheetName);
			// page classes initiation

			int rows = start.xldriver.get_used_rows();
			for (int i = 2; i <= rows; i++) {
				st = new start();
				String username = start.xldriver.getExcelData("username", i);
				String password = start.xldriver.getExcelData("password", i);
				System.out.println("Password " + password);
				st.launch_browser().goTo_Home()
						.enter_username_and_click_logon(username)
						.enter_password_and_click_logon(password)
						.goTo_landing().checkmyprofilelink().logout()
						.tearDown();

			}

		} catch (Exception e) {
			start.logger.log(LogStatus.FAIL, "unexpected error "
					+ e.getStackTrace().toString());
			e.printStackTrace();
			start.extent.flush();

		} finally {
			start.extent.flush();

		}
	}

}
